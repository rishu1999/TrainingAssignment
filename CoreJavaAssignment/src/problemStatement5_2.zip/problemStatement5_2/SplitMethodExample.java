package problemStatement5_2;

public class SplitMethodExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String txt= (" 23  +  45  -  (  343  /  12  ) ");
		String[] s=txt.split("\\s");
		
		for(String s1:s){  
			System.out.println(s1);
		}
	}

}
