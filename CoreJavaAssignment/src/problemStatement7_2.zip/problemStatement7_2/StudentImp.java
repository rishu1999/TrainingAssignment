package problemStatement7_2;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class StudentImp {

	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		String name = "";
		String address = "";
		int age = 0;
		int rollNo = 0;
		String choice = null;

		do {

			System.out.println("Enter name: ");
			name = sc.next();

			System.out.println("Enter address: ");
			address = sc.next();

			System.out.println("Enter roll no: ");
			rollNo = sc.nextInt();

			System.out.println("Enter age between 5 and 25: ");
			age = sc.nextInt();
			try {

				if (name == "" || (age < 5 && age > 25) || rollNo < 0 || address == "") {
					throw new FieldEmptyException();
				}
			} catch (FieldEmptyException e) {
				System.out.println(e);
			}
			
			Student st = new Student(name, age, rollNo, address);
			System.out.println("Want to save student in file yes/no? ");
			choice = sc.next();
			if (choice.equals("yes")) {
				FileOutputStream fs = new FileOutputStream("students.txt");
				ObjectOutputStream out = new ObjectOutputStream(fs);
				out.writeObject(st);
				out.flush();
				out.close();
				System.out.println("object added to the file");
			} else {
				System.out.println("programm terminated!!!");
			}
			
		} while (choice.equals("no") == false);
		
		

	}

}